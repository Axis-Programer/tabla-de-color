const colorInput = document.querySelector('#color')

colorInput.addEventListener('input',()=>{
    let color = colorInput.value;
    hex.style.color = color;
    hex.innerHTML = color;
    contDiv.style.borderColor = color;
})